<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Kas</title>
         <link rel = "stylesheet" type="text/css" href= "{{asset('/css/app.css')}}">

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <style>
            html, body {
                background-color: plum;
                color: black;
                font-family: Times New Roman;
                text-align: center;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .kas {
                font-size: 24px;
                font-family: Lucida Calligraphy;
                text-align: center;
            }
            .kas1 {
                font-size: 15px;
                font-family: Lucida Sans;
                text-align: left;
            }

        </style>
    </head>
    <body>
        <header>
        <div class="kas">
            <h2>Data Kas Santri Daarul Anba</h2>     
        </div>
        <nav>
            <a href="/Kas">HOME</a>
            |
            <a href="/masuk">KAS MASUK</a>
            |
            <a href="/Kas2">KAS KELUAR</a>
            </nav>
            <div class="kas">
            <h2>=======================================================</h2>     
        </div>
        <br/>
    </header>
        <div class="kas1">
            <a href="/Kas2/tambah" method="GET" class="Kas2">
                <center><input class = "btn btn-primary ml-3" type="Simpan" value="Tambah Data"> </center>
            </a>
            <br/>
            <br/>
 
                <center> <table class="table table-bordered">
                <tr>
                <td align="center">Kode</td>
                <td align="center">Tanggal</td>
                <td align="center">Keterangan</td>
                <td align="center">Jumlah</td>
                <td align="center">Opsi</td>
                    
                </tr>
                @foreach($keluar as $k)
                <tr>
                    <td>{{ $k->kode }}</td>
                    <td>{{ $k->tgl }}</td>
                    <td>{{ $k->keterangan }}</td>
                    <td>{{ $k->jumlah }}</td>
                    <td>
                    <center><a class="btn btn-warning btn-sm" href="/Kas2/edit/{{ $k->kode}}">Edit</a>
                    
                    <a class="btn btn-danger btn-sm" href="/Kas2/hapus/{{ $k->kode}}">Hapus</a></center>
                    </td>
                </tr>
                @endforeach
            </table>
        </div>
    </body>
</html>