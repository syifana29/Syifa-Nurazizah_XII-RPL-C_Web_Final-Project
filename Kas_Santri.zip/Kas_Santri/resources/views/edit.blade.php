<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Kas</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <style>
            html, body {
                background-color: plum;
                color: black;
                font-family: Lucida Calligraphy;
                font-size: 30px;
                text-align: center;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .kas {
                font-size: 18px;
                font-family: Comic Sans MS;
                text-align: left;
            
            }
            .judul {
                text-align: center;
            }
            .table {
                border-collapse: collapse;
            
            }.table,th,td {
                border: 1px solid black;
            
            }.th,td {
                padding: 10px;
            
            }
        </style>
    </head>
    <body>
           
        <h3>Edit Data Kas Keluar Santri Daarul Anba</h3>
        <div class="kas">
            <a href="/Kas2">Kembali</a>
            @foreach($keluar as $k)
            <form action="/Kas2/update" method="post">
                {{ csrf_field() }}
                <input type="hidden" name="id" value="{{ $k->kode }}"> <br/>
                Tanggal <input type="date" required="required" name="tgl" value="{{ $k->tgl }}"> <br/>
                Keterangan <input type="text" required="required" name="keterangan"value="{{ $k->keterangan }}"> <br/>
                Jumlah <input type="text" required="required" name="jumlah" value="{{ $k->jumlah }}"> <br/>
                <input type="submit" value="Simpan Data">
            </form>
            @endforeach

        </div>
 </body>
</html>