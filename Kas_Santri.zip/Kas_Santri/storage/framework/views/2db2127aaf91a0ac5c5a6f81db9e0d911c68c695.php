<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Kas</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <style>
            html, body {
                background-color: plum;
                color: black;
                font-family: Lucida Calligraphy;
                font-size: 30px;
                text-align: center;
                font-weight: 200;
                height: 200vh;
                margin: 0;
            }

            .kas {
                font-size: 24px;
                font-family: Comic Sans MS;
                text-align: left;
            
            }


        </style>
    </head>
    <body>
        <h3>Tambah Data Kas Keluar Santri Daarul Anba</h3>
        <div class="kas">
            <a href="/Kas2">Kembali</a>
         
            <form action="/Kas2/create" method="post">
                <?php echo e(csrf_field()); ?>

                Kode <input type="text" name="kode" required="required"> <br/>
                Tanggal <input type="date" name="tgl" required="required"> <br/>
                Keterangan <textarea required="required" name="keterangan"></textarea><br/>
                Jumlah <input type="text" name="jumlah" required="required"> <br/>
                <input type="submit" value="Simpan Data">
            </form>
        </div>
</body>
</html><?php /**PATH C:\xamppp\htdocs\Kas_Santri\resources\views/tambah.blade.php ENDPATH**/ ?>