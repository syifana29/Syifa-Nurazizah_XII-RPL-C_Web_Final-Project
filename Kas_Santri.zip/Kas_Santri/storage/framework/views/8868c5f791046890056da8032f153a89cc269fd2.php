<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Absensi</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <style>
            html, body {
                background-color: plum;
                color: black;
                font-family: Times New Roman;
                text-align: center;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .kas {
                font-size: 24px;
                font-family: Lucida Calligraphy;
                text-align: center;
            }
            .home {
                font-size: 44px;
                font-family: Lucida Calligraphy;
                text-align: center;
            }

        </style>
    </head>
    <body>
        <header>
        <div class="kas">
            <h2>Data Kas Santri Daarul Anba</h2>     
        </div>
        <nav>
            <a href="/Kas">HOME</a>
            |
            <a href="/Kas1">KAS MASUK</a>
            |
            <a href="/Kas2">KAS KELUAR</a>
            |
            <a href="/Kas3">REKAPITULASI KAS</a>
            </nav>
            <div class="kas">
            <h2>=============================================</h2>     
        </div>
        <br/>
    </header>
    <div class="home">
            Selamat Datang di Kas Santri Daarul Anba
        </div>
    </body>
</html><?php /**PATH C:\xamppp\htdocs\Tugas\resources\views/index.blade.php ENDPATH**/ ?>