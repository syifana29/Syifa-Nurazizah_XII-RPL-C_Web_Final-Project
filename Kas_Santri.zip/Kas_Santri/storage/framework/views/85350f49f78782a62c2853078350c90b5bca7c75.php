<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Absensi</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <style>
            html, body {
                background-color: plum;
                color: black;
                font-family: Times New Roman;
                text-align: center;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .kas {
                font-size: 24px;
                font-family: Lucida Calligraphy;
                text-align: center;
            }
            .kas1 {
                font-size: 15px;
                font-family: Lucida Sans;
                text-align: left;
            }

        </style>
    </head>
    <body>
        <header>
        <div class="kas">
            <h2>Data Kas Santri Daarul Anba</h2>     
        </div>
        <nav>
            <a href="/Kas">HOME</a>
            |
            <a href="/masuk">KAS MASUK</a>
            |
            <a href="/Kas2">KAS KELUAR</a>
            </nav>
            <div class="kas">
            <h2>=======================================================</h2>     
        </div>
        <br/>
    </header>
        <div class="kas1">
            <a href="/masuk/tambah1"> + Tambah Data</a>
            
            <br/>
            <br/>
         
            <table border="1" cellpadding="8">
                
                <td align="center">Kode</td>
                <td align="center">Tanggal</td>
                <td align="center">Keterangan</td>
                <td align="center">Jumlah</td>
                <td align="center">Opsi</td>
                    
                </tr>
                <?php $__currentLoopData = $masuk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($k->kode); ?></td>
                    <td><?php echo e($k->tgl); ?></td>
                    <td><?php echo e($k->keterangan); ?></td>
                    <td><?php echo e($k->jumlah); ?></td>
                    <td>
                    <a href="/masuk/edit1/<?php echo e($k->kode); ?>">Edit</a>
                    |
                    <a href="/masuk/hapus1/<?php echo e($k->kode); ?>">Hapus</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </body>
</html><?php /**PATH C:\xamppp\htdocs\Absensi_Santri\resources\views/masuk.blade.php ENDPATH**/ ?>