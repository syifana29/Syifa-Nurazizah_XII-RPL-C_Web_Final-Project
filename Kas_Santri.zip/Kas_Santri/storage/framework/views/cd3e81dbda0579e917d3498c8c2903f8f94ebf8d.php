<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <style>
            html, body {
                background-color: plum;
                color: black;
                font-family: Lucida Calligraphy;
                font-size: 30px;
                text-align: center;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .kas {
                font-size: 18px;
                font-family: Comic Sans MS;
                text-align: left;
            
            }
            .judul {
                text-align: center;
            }
            .table {
                border-collapse: collapse;
            
            }.table,th,td {
                border: 1px solid black;
            
            }.th,td {
                padding: 10px;
            
            }

        </style>
    </head>
    <body>
        <h3>Kas Santri Daarul Anba</h3>
        <div class="kas">
            <a href="/Kas1/tambah"> + Tambah Data</a>
            
            <br/>
            <br/>
         
            <table border="1" cellpadding="8">
                
                <td align="center">Kode</td>
                <td align="center">Tanggal</td>
                <td align="center">Keterangan</td>
                <td align="center">Jumlah</td>
                <td align="center">Opsi</td>
                    
                </tr>
                <?php $__currentLoopData = $masuk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($m->kode); ?></td>
                    <td><?php echo e($m->tgl); ?></td>
                    <td><?php echo e($m->keterangan); ?></td>
                    <td><?php echo e($m->jumlah); ?></td>
                    <td>
                    <a href="/Kas1/edit/<?php echo e($m->kode); ?>">Edit</a>
                    |
                    <a href="/Kas1/hapus/<?php echo e($m->kode); ?>">Hapus</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
</body>
</html><?php /**PATH C:\xamppp\htdocs\Tugas\resources\views/masuk.blade.php ENDPATH**/ ?>