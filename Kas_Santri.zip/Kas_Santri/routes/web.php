<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

//route CRUD
Route::get('/Kas', 'SantriController@index');

Route::get('/masuk', 'MasukController@masuk');
Route::get('/masuk/tambah1','MasukController@tambah1');
Route::post('/masuk/create1','MasukController@create1');
Route::get('/masuk/edit1/{id}','MasukController@edit1');
Route::post('/masuk/update1','MasukController@update1');
Route::get('/masuk/hapus1/{id}','MasukController@hapus1');

Route::get('/Kas2', 'KasController@keluar');
Route::get('/Kas2/tambah','KasController@tambah');
Route::post('/Kas2/create','KasController@create');
Route::get('/Kas2/edit/{id}','KasController@edit');
Route::post('/Kas2/update','KasController@update');
Route::get('/Kas2/hapus/{id}','KasController@hapus');

Route::get('/Kas3rekap', 'Kas2Controller@rekap');
