<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class KasController extends Controller
{
   public function keluar()
    {
    	// mengambil data dari table pegawai
    	$keluar = DB::table('keluar')->get();
 
    	// mengirim data pegawai ke view index
    	return view('keluar',['keluar' => $keluar]);
 
    }

    public function tambah()
	{
 
	// memanggil view tambah
	return view('tambah');
 
	}


	public function create(Request $request)
	{
	// insert data ke table siswa
	DB::table('keluar')->insert([
		'kode' => $request->kode,
		'tgl' => $request->tgl,
		'keterangan' => $request->keterangan,
		'jumlah' => $request->jumlah
	]);
	// alihkan halaman ke halaman siswa
	return redirect('/Kas2');
 
	}

	// method untuk edit data pegawai
	public function edit($id)
	{
		// mengambil data pegawai berdaasarkan id yang dipilih
		$keluar = DB::table('keluar')->where('kode',$id)->get();
		// passing data pegawai yang didapat ke view edit.blade.php
		return view('edit',['keluar' => $keluar]);
	 
	}

	public function update(Request $request)
	{
	// update data pegawai
	DB::table('keluar')->where('kode',$request->id)->update([
		'tgl' => $request->tgl,
		'keterangan' => $request->keterangan,
		'jumlah' => $request->jumlah
	]);
	// alihkan halaman ke halaman pegawai
	return redirect('/Kas2');
	}

	// method untuk hapus data pegawai
	public function hapus($id)
	{
		// menghapus data pegawai berdasarkan id yang dipilih
		DB::table('keluar')->where('kode',$id)->delete();
			
		// alihkan halaman ke halaman pegawai
		return redirect('/Kas2');
	}
}
