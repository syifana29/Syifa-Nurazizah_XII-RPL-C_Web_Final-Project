<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class MasukController extends Controller
{
   public function masuk()
    {
    	// mengambil data dari table pegawai
    	$masuk = DB::table('masuk')->get();
 
    	// mengirim data pegawai ke view index
    	return view('masuk',['masuk' => $masuk]);
 
    }

    public function tambah1()
	{
 
	// memanggil view tambah
	return view('tambah1');
 
	}


	public function create1(Request $request)
	{
	// insert data ke table siswa
	DB::table('masuk')->insert([
		'kode' => $request->kode,
		'tgl' => $request->tgl,
		'keterangan' => $request->keterangan,
		'jumlah' => $request->jumlah
	]);
	// alihkan halaman ke halaman siswa
	return redirect('/masuk');
 
	}

	// method untuk edit data pegawai
	public function edit1($id)
	{
		// mengambil data pegawai berdaasarkan id yang dipilih
		$masuk = DB::table('masuk')->where('kode',$id)->get();
		// passing data pegawai yang didapat ke view edit.blade.php
		return view('edit1',['masuk' => $masuk]);
	 
	}

	public function update1(Request $request)
	{
	// update data pegawai
	DB::table('masuk')->where('kode',$request->id)->update([
		'tgl' => $request->tgl,
		'keterangan' => $request->keterangan,
		'jumlah' => $request->jumlah
	]);
	// alihkan halaman ke halaman pegawai
	return redirect('/masuk');
	}

	// method untuk hapus data pegawai
	public function hapus1($id)
	{
		// menghapus data pegawai berdasarkan id yang dipilih
		DB::table('masuk')->where('kode',$id)->delete();
			
		// alihkan halaman ke halaman pegawai
		return redirect('/masuk');
	}
}
